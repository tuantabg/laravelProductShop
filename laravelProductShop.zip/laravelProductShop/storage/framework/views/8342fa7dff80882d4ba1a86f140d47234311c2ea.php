<?php $__env->startSection('title', 'Register'); ?>
<?php $__env->startSection('content'); ?>
<div class="reg-w3">
    <div class="w3layouts-main">
        <h2>Đăng Ký Tài khoản</h2>
        <form action="#" method="post">
            <input type="text" class="ggg" name="name" placeholder="Họ & Tên" required="">
            <input type="email" class="ggg" name="email" placeholder="E-MAIL" required="">
            <input type="text" class="ggg" name="phone" placeholder="Số Điện Thoại" required="">
            <input type="password" class="ggg" name="password" placeholder="Mật Khẩu" required="">
            <h4><input type="checkbox" />Tôi đồng ý với Điều khoản dịch vụ và Chính sách quyền riêng tư.</h4>

            <div class="clearfix"></div>
            <input type="submit" value="Đăng Ký" name="register">
        </form>
        <p>Đã có tài khoản.<a href="login.html">Đăng nhập</a></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tuanta/Public/ProjectLearning/laravelProductShop/resources/views/auth/register.blade.php ENDPATH**/ ?>