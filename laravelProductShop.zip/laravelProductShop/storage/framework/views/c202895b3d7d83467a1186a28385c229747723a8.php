<?php $__env->startSection('title', 'Tạo Danh Mục Sản Phẩm'); ?>
<?php $__env->startSection('content'); ?>
    <section class="panel">
        <header class="panel-heading">
            Tạo Danh Mục Sản Phẩm
        </header>
        <div class="panel-body">
            <form action="<?php echo e(route('postCategoryProduct')); ?>" class="form-horizontal bucket-form" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="categoryProductName" class="col-sm-3 control-label">Tên danh mục</label>
                    <div class="col-sm-6">
                        <input type="text" name="category_product_name" id="categoryProductName" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="categoryProductDesc" class="col-sm-3 control-label">Mô tả danh mục</label>
                    <div class="col-sm-6">
                        <textarea name="category_product_desc" id="categoryProductDesc" class="form-control" cols="15" rows="3"></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label col-lg-3" for="categoryProductActive">Hiển thị</label>
                    <div class="col-lg-6">
                        <select name="category_product_status" id="categoryProductActive" class="form-control m-bot15">
                            <option value="0">Hiển thị</option>
                            <option value="1">Ẩn</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-3"></div>
                    <div class="col-lg-6">
                        <input type="submit" class="btn btn-info" value="Tạo danh mục" name="add_category_product">
                    </div>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tuanta/Public/ProjectLearning/laravelProductShop/resources/views/admin/page/category/add.blade.php ENDPATH**/ ?>