<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <title>E-Shopper - <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>" >
    <link href="<?php echo e(asset('admin/css/style.css')); ?>" rel='stylesheet' type='text/css' />
    <link href="<?php echo e(asset('admin/css/style-responsive.css')); ?>" rel="stylesheet"/>
    <link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/font.css')); ?>" type="text/css"/>
    <link href="<?php echo e(asset('admin/css/font-awesome.css')); ?>" rel="stylesheet">

    <!-- Custom Javascript -->
    <script src="<?php echo e(asset('admin/js/jquery2.0.3.min.js')); ?>"></script>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>

    <script src="<?php echo e(asset('admin/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/jquery.dcjqaccordion.2.7.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/jquery.slimscroll.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/jquery.nicescroll.js')); ?>"></script>
    <!--[if lte IE 8]><script language="javascript" type="text/javascript" src="<?php echo e(asset('admin/js/flot-chart/excanvas.min.js')); ?>"></script><![endif]-->
    <script src="<?php echo e(asset('admin/js/jquery.scrollTo.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/tuanta/Public/ProjectLearning/laravelProductShop/resources/views/auth/app.blade.php ENDPATH**/ ?>