<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>
<div class="log-w3">
    <div class="w3layouts-main">
        <h2>Đăng Nhập Tài Khoản</h2>

        <?php if(count($errors) >0): ?>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-danger"> <?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>

        <?php if(session('status')): ?>
            <ul>
                <li class="text-danger"> <?php echo e(session('status')); ?></li>
            </ul>
        <?php endif; ?>

        <form action="<?php echo e(route('postLogin')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="email" class="ggg" name="admin_email" placeholder="E-MAIL" required="">
            <input type="password" class="ggg" name="admin_password" placeholder="Mật Khẩu" required="">
            <label><input type="checkbox" />Nhớ đăng nhập</label>
            <h6><a href="#">Quên mật khẩu?</a></h6>
            <div class="clearfix"></div>
            <input type="submit" value="Đăng Nhập" name="login">
        </form>
        <p>Không có tài khoản ?<a href="registration.html">Tạo tài khoản</a></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tuanta/Public/ProjectLearning/laravelProductShop/resources/views/auth/login.blade.php ENDPATH**/ ?>