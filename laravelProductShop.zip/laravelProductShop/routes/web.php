<?php

use App\Http\Controllers\Client\HomeController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\CategoryProductController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// Route Client
Route::get('/', [HomeController::class, 'index']);

// Route Auth
Route::get('/login', [AdminController::class, 'login'])->name('getLogin');
Route::post('/login', [AdminController::class, 'postLogin'])->name('postLogin');
Route::get('/register', [AdminController::class, 'register'])->name('getRegister');
Route::post('/register', [AdminController::class, 'postRegister'])->name('postRegister');
Route::get('/logout', [AdminController::class, 'getLogout'])->name('getLogout');

// Route Dashboard
Route::get('/dashboard', [AdminController::class, 'index'])->name('showDashboard');


// Category Product
Route::get('/list-category-product', [CategoryProductController::class, 'index'])->name('getListCategoryProduct');
Route::get('/add-category-product', [CategoryProductController::class, 'getCategoryProduct'])->name('getCategoryProduct');
Route::post('/add-category-product', [CategoryProductController::class, 'postCategoryProduct'])->name('postCategoryProduct');






