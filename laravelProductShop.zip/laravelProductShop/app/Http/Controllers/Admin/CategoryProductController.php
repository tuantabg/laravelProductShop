<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class CategoryProductController extends Controller
{
    public function index()
    {
        return view('admin.page.category.list');
    }

    public function getCategoryProduct()
    {
        return view('admin.page.category.add');
    }

    public function postCategoryProduct(Request $request)
    {
        $data = array();
        $data['category_name'] = $request->category_product_name;
        $data['category_desc'] = $request->category_product_desc;
        $data['category_status'] = $request->category_product_status;

        DB::table('category_product_table')->insert($data);

        return redirect()
            ->route('getListCategoryProduct')
            ->with('status', 'Thêm danh mục sản phẩm thành công');
    }
}
