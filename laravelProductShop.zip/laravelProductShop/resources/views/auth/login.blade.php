@extends('auth.app')
@section('title', 'Login')
@section('content')
<div class="log-w3">
    <div class="w3layouts-main">
        <h2>Đăng Nhập Tài Khoản</h2>

        @if (count($errors) >0)
            <ul>
                @foreach($errors->all() as $error)
                    <li class="text-danger"> {{ $error }}</li>
                @endforeach
            </ul>
        @endif

        @if (session('status'))
            <ul>
                <li class="text-danger"> {{ session('status') }}</li>
            </ul>
        @endif

        <form action="{{ route('postLogin') }}" method="post">
            {{ csrf_field() }}
            <input type="email" class="ggg" name="admin_email" placeholder="E-MAIL" required="">
            <input type="password" class="ggg" name="admin_password" placeholder="Mật Khẩu" required="">
            <label><input type="checkbox" />Nhớ đăng nhập</label>
            <h6><a href="#">Quên mật khẩu?</a></h6>
            <div class="clearfix"></div>
            <input type="submit" value="Đăng Nhập" name="login">
        </form>
        <p>Không có tài khoản ?<a href="registration.html">Tạo tài khoản</a></p>
    </div>
</div>
@endsection
