@extends('auth.app')
@section('title', 'Register')
@section('content')
<div class="reg-w3">
    <div class="w3layouts-main">
        <h2>Đăng Ký Tài khoản</h2>
        <form action="{{ route('postRegister') }}" method="post">
            {{ csrf_field() }}
            <input type="text" class="ggg" name="name" placeholder="Họ & Tên" required="">
            <input type="email" class="ggg" name="email" placeholder="E-MAIL" required="">
            <input type="text" class="ggg" name="phone" placeholder="Số Điện Thoại" required="">
            <input type="password" class="ggg" name="password" placeholder="Mật Khẩu" required="">
            <h4><input type="checkbox" />Tôi đồng ý với Điều khoản dịch vụ và Chính sách quyền riêng tư.</h4>

            <div class="clearfix"></div>
            <input type="submit" value="Đăng Ký" name="register">
        </form>
        <p>Đã có tài khoản.<a href="login.html">Đăng nhập</a></p>
    </div>
</div>
@endsection
