<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);

        DB::table('user_admin')->insert([
            'admin_name' => 'admin',
            'admin_email' => 'admin@gmail.com',
            'admin_password' => md5('admin123'),
            'admin_image' => 'https://qsh.at/FAZ',
            'admin_phone' => '0123456789',
        ]);
    }
}
